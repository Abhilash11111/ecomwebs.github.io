
<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="abt.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
  
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Government Beneficiary Portal</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
          
    </ul>
    
  </div>
</nav>

<section class="my-5">
    <div class="py-2">
        <h2 class="text-center" style="color:#4caf50">About Us</h2>
    </div>
    <div class="container fluid">
        <div class="row">
            <p style="color:black">Governments beneficiary portal, is a website which provides information about the plans and schemes by the Government of their respective states and regions .It is useful for all age groups .The objective behind the Portal is to provide a single window access to the information and services being provided by the Indian Government for citizens and other stakeholders. An attempt has been made through this Portal to provide comprehensive, accurate, reliable and one stop source of information about India and its various facts. The current Portal includes various sectors information like Agriculture, Social development ,Education ,Food & Public Distribution , Labour & employment ,Governance & Administration ,Health & Family Welfare, And Youth & Sports.</p>            
            <img src="img5.jpg" alt="Paris" class="center">>
            </div>
        </div>
    </div>
</section>


</body>
</html>