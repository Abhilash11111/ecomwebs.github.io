<!DOCTYPE html>
<html>
<head>
    <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link href='https://fonts.googleapis.com/css?family=Acme' rel='stylesheet'>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  
</head>
<body>
<?php
   //home.php
   session_start();
   if(!isset($_SESSION["Username"]))
   {
    header("location: login.php");
   }
   else{
    echo '<p align="center"><a href="logout.php">Logout</a></p>';
   }
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Government Beneficiary Portal</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
      
    </ul>
   
  </div>
</nav>
<section class="my-5">
    <div class="py-2">
        <h2 class="text-center" style="color:#4caf50">Choose Your Domain</h2>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="agri.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">Agriculture</h4>
                <a href="http://agricoop.gov.in/divisiontype/rainfed-farming-system/programmes-schemes-new-initiatives" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="health.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">Health</h4>
                <a href="https://www.india.gov.in/topics/health-family-welfare" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="ngo.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">NGO Schemes</h4>
                <a href="https://ngosindia.com/funding-agencies/government-funding-ministries/" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="women.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">Women Empowerment</h4>
                <a href="https://wcd.nic.in/schemes-listing/2405" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
        </div>
    </div>
</section>
<section class="my-5">
    <div class="py-2">
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="disable1.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">Disabled People</h4>
                <a href="https://vikaspedia.in/social-welfare/differently-abled-welfare/schemes-programmes" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="rural1.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">Rural</h4>
                <a href="https://www.jagranjosh.com/general-knowledge/list-of-various-rural-development-schemes-in-india-1480939663-1" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="urban3.jpg" alt="Card image">
              <div class="card-body">
                <h4 class="card-title">Urban</h4>
                <a href="https://www.manifestias.com/2019/07/19/urban-development-schemes/" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
            <div class="card">
              <img class="card-img-top" src="tribal3.jpg" alt="Card image">
              <div class="card-body">
                <h6 class="card-title">Tribal</h6>
                <a href="https://pib.gov.in/Pressreleaseshare.aspx?PRID=1575524" class="btn btn-primary">View</a>
              </div>
            </div>
            </div>
        </div>
    </div>
</section>




</body>
</html>